# API.ai.com

A secure Node.js Express API for AI-related services.

## Features
- User authentication with JWT
- Role-based access control (Superadmin, Admin, User)
- OWASP security implementations (Rate limiting, Input sanitization, Helmet, etc.)
- MongoDB integration
- File upload support
- Logging with Winston
- CORS configuration

## Installation

1. Clone the repository
2. Install dependencies: `npm install`
3. Create a `.env` file with required environment variables
4. Start the server: `npm start`

## Environment Variables

- PORT
- NODE_ENV
- MONGODB_URI
- JWT_SECRET
- SUPERADMIN, MANAGER, ADMIN, USER (roles)

## API Endpoints

### Authentication
- POST /api/auth/sendOtp - Send OTP (Superadmin only)

## Security
This project follows OWASP guidelines with rate limiting, input validation, and secure headers.

## License
ISC