import express from 'express';
import superadmin from './superadmin/auth.js';

const router = express.Router();

router.use('/auth', superadmin);

export default router;