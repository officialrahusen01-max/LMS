import express from 'express';
import { authentication, RoleAccess } from '../../middleware/authentication.js';
import config from '../../configuration/config.js';
import AuthController from '../../controllers/superadmin/authController.js';

const router = express.Router();

router.post('/sendOtp', AuthController.sendOtp)
      .post('/login', AuthController.login)
      .post('/refresh', AuthController.refreshToken);


export default router;