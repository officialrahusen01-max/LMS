import config from "../../configuration/config.js";
import User from "../../models/auth/Users.js";
import RefreshToken from "../../models/auth/RefreshToken.js";
import sendOtp from "../../utils/sendOtp.js";
import jwt from "jsonwebtoken";

class AuthService {
    static async sendOtp(req, res) {
        const { email } = req.body;
        const user = await User.findOne({ 
            where: { email, role: config.SUPERADMIN }
         });
        if (!user) {
            throw new Error('User not found');
        }
        const otp = Math.floor(100000 + Math.random() * 900000).toString();

        await sendOtp(email, otp);
        return { email, otp };
    }

    static async login(req, res) {
        const { email, otp } = req.body;
        const user = await User.findOne({ 
            where: { email, role: config.SUPERADMIN }
         });
        if (!user) {
            throw new Error('User not found');
        }
        const token = user.generateAuthToken();
        const refreshToken = user.generateRefreshToken();

        const accessExpiresIn = config.JWT_EXPIRES_IN === '1h' ? 3600000 : 3600000; // default 1h
        const refreshExpiresIn = config.REFRESH_TOKEN_EXPIRES_IN === '7d' ? 604800000 : 604800000; // default 7d

        const accessExpiresAt = new Date(Date.now() + accessExpiresIn);
        const refreshExpiresAt = new Date(Date.now() + refreshExpiresIn);

        // Save to RefreshToken table
        await RefreshToken.create({
            userId: user._id,
            accessToken: token,
            refreshToken: refreshToken,
            accessExpiresAt,
            refreshExpiresAt,
        });

        return { token, refreshToken };
    }

    static async refreshToken(req, res) {
        const { refreshToken } = req.body;
        if (!refreshToken) {
            throw new Error('Refresh token is required');
        }

        // Find the refresh token in DB
        const tokenDoc = await RefreshToken.findOne({ refreshToken, isRevoked: false });
        if (!tokenDoc) {
            throw new Error('Invalid refresh token');
        }

        // Check if refresh token is expired
        if (new Date() > tokenDoc.refreshExpiresAt) {
            throw new Error('Refresh token expired');
        }

        // Get user
        const user = await User.findById(tokenDoc.userId);
        if (!user) {
            throw new Error('User not found');
        }

        // Generate new access token
        const newToken = user.generateAuthToken();
        const accessExpiresIn = config.JWT_EXPIRES_IN === '1h' ? 3600000 : 3600000;
        const newAccessExpiresAt = new Date(Date.now() + accessExpiresIn);

        // Update the document with new access token
        tokenDoc.accessToken = newToken;
        tokenDoc.accessExpiresAt = newAccessExpiresAt;
        await tokenDoc.save();

        return { token: newToken };
    }
}

export default AuthService;