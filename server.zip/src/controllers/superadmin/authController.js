import AuthService from "../../services/superadmin/authService.js";
import catchAsync from "../../utils/catchAsync.js";

class AuthController {
 static sendOtp = catchAsync(async (req, res) => {
    const response = await AuthService.sendOtp(req.body);
    res.status(200).json({ message: 'OTP sent successfully', data: response });
  });

  static login = catchAsync(async (req, res) => {
    const response = await AuthService.login(req.body);
    res.status(200).json({ message: 'Login successful', data: response });
  });

  static refreshToken = catchAsync(async (req, res) => {
    const response = await AuthService.refreshToken(req.body);
    res.status(200).json({ message: 'Token refreshed', data: response });
  });
export default AuthController;