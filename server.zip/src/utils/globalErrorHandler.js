const globalErrorHandler = (err, req, res, next) => {
    const statusCode = err.statusCode || 200;
    console.log(err)
    res.status(statusCode).json({
        status: false,
        message: err.message || 'Internal Server Error',
    });
};

export default globalErrorHandler;
